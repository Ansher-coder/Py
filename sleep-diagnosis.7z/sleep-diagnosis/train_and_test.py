import pandas as pd
import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np
from sklearn.neighbors import kneighbors_graph

# 加载数据集
data = pd.read_csv('gnn_enh_think/ot/atest.csv')

# 检查缺失值

# 处理缺失值（选择一种方法）
data = data.dropna()  # 或者 data.fillna(data.mean(), inplace=True)

# 数据预处理
features = data.drop('diagnosis', axis=1)  # 特征
labels = data['diagnosis'].values  # 标签

# 标准化特征
scaler = StandardScaler()
features = scaler.fit_transform(features)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.01, random_state=45)

# 计算训练集和测试集的样本数量
num_train_samples = X_train.shape[0]
num_test_samples = X_test.shape[0]

# 确保k不超过样本数量
k = min(160, num_train_samples)  # 对于训练集
k_test = min(7, num_test_samples)  # 对于测试集

# 构建训练集的邻接矩阵
adjacency_matrix = kneighbors_graph(X_train, n_neighbors=k, mode='connectivity', include_self=True).toarray()
edge_index = np.array(np.nonzero(adjacency_matrix))  # 转换为edge_index格式

# 创建PyTorch Geometric数据对象
train_data = Data(x=torch.tensor(X_train, dtype=torch.float), edge_index=torch.tensor(edge_index, dtype=torch.long), y=torch.tensor(y_train, dtype=torch.long))

# 定义GNN模型
class GNNModel(torch.nn.Module):
    def __init__(self):
        super(GNNModel, self).__init__()
        self.conv1 = GCNConv(in_channels=X_train.shape[1], out_channels=64)
        self.conv2 = GCNConv(in_channels=64, out_channels=32)
        self.fc = torch.nn.Linear(32, 55)  # 假设有54个类别

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = self.fc(x)
        return F.log_softmax(x, dim=1)

# 训练模型
model = GNNModel()
optimizer = torch.optim.Adam(model.parameters(), lr=0.0004, weight_decay=1e-5)  # 添加权重衰减

# 训练循环
for epoch in range(400):
    model.train()
    optimizer.zero_grad()
    out = model(train_data)
    loss = F.nll_loss(out, train_data.y)
    loss.backward()
    optimizer.step()
    if epoch % 10 == 0:
        print(f'Epoch {epoch}, Loss: {loss.item():.4f}')

# 保存模型
torch.save(model.state_dict(), 'gnn_enh_think/ot/gnn_model.pth')
print("model saved in gnn_model.pth")

# 评估模型
model.eval()
with torch.no_grad():
    # 构建测试数据的邻接矩阵
    adjacency_matrix_test = kneighbors_graph(X_test, n_neighbors=k_test, mode='connectivity', include_self=True).toarray()
    edge_index_test = np.array(np.nonzero(adjacency_matrix_test))  # 转换为edge_index格式
    test_data = Data(x=torch.tensor(X_test, dtype=torch.float), edge_index=torch.tensor(edge_index_test, dtype=torch.long), y=torch.tensor(y_test, dtype=torch.long))
    
    pred = model(test_data).max(dim=1)[1]  # 获取预测类别
    accuracy = (pred == test_data.y).sum().item() / test_data.y.size(0)
    print(f'Test Accuracy: {accuracy:.2f}')

# 进行预测
new_data = pd.read_csv('gnn_enh_think/ot/chk.csv')
new_data_scaled = scaler.transform(new_data)

# 构建新数据的邻接矩阵
adjacency_matrix_new = kneighbors_graph(new_data_scaled, n_neighbors=min(5, new_data_scaled.shape[0]), mode='connectivity', include_self=True).toarray()
edge_index_new = np.array(np.nonzero(adjacency_matrix_new))  # 转换为edge_index格式
new_data_tensor = Data(x=torch.tensor(new_data_scaled, dtype=torch.float), edge_index=torch.tensor(edge_index_new, dtype=torch.long))

model.eval()
with torch.no_grad():
    pred = model(new_data_tensor).max(dim=1)[1]  # 获取预测类别

# 打印预测结果
print("diagnosis:", pred.numpy())